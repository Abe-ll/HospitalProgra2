-- Actualiza la tabla existente sin eliminar pacientes.
-- Ejecutar una sola vez y solo si falta la columna urgencia.
-- Los pacientes anteriores quedan con el valor 'Sin asignar'.

USE hospital_db;

ALTER TABLE pacientes
ADD COLUMN urgencia VARCHAR(20) NOT NULL DEFAULT 'Sin asignar';
