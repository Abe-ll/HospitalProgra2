package hospital;

import hospital.ui.PacientesFrame;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PacientesFrame().setVisible(true));
    }
}
