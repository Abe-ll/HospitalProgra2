package hospital.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Conexión JDBC. Ajuste CLAVE con su contraseña de MySQL. */
public class Conexion {
    private static final String URL = "jdbc:mysql://localhost:3307/hospital_db?useSsl=false&allowPublicKeyRetrieval=true";
    private static final String USUARIO = "root";
    private static final String CLAVE = "";

    public static Connection obtener() throws SQLException {
        try {
            Class.forName("org.mariadb.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Falta lib/mariadb-java-client.jar en las Libraries del proyecto.", e);
        }
        return DriverManager.getConnection(URL, USUARIO, CLAVE);
    }
}
