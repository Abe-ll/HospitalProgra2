package hospital.dao;

import hospital.modelo.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {

     /**
     * Guarda los datos obtenidos de un paciente en la base de datos final.
     *
     * Recibe el objeto construido por el formulario de admisión y obtiene
     * sus datos mediante getters. El nombre, apellido y edad se consultan
     * mediante los métodos que Paciente hereda de Persona.
     *
     * El identificador y la fecha de ingreso no se incluyen en el INSERT,
     * porque la base de datos los genera automáticamente al momento de 
     * ingresar.
     *
     * @throws SQLException si falla la conexión o la inserción
     * @param p paciente con sus datos personales, motivo y urgencia
     */
    
    
    public void insertar(Paciente p) throws SQLException {
        String sql = "INSERT INTO pacientes (nombre, apellido, edad, motivo, urgencia) VALUES (?,?,?,?,?)";
        try (Connection cn = Conexion.obtener(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getApellido());
            ps.setInt(3, p.getEdad());
            ps.setString(4, p.getMotivo());
            // Guarda la urgencia asignada en el formulario de admisión.
            // (Añadido en modulo 2)
            ps.setString(5, p.getUrgencia());
            ps.executeUpdate();
        }
    }

    
    /**
     * Consulta los pacientes registrados, del más reciente al más antiguo.
     *
     * Recorre el resultado de la consulta y construye un objeto Paciente
     * por cada registro. También recupera su identificador, fecha de ingreso
     * y nivel de urgencia.
     *
     * Este método devuelve los objetos; cargarTabla() se encarga
     * de mostrar sus datos en la JTable.
     *
     * @return lista de pacientes; estará vacía si no hay registros
     * @throws SQLException si falla la conexión o la consulta
     */
    
    public List<Paciente> listar() throws SQLException {
        List<Paciente> lista = new ArrayList<>();
        String sql = "SELECT id, nombre, apellido, edad, motivo, urgencia, fecha_ingreso FROM pacientes ORDER BY id DESC";
        try (Connection cn = Conexion.obtener();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Paciente p = new Paciente(rs.getString("nombre"), rs.getString("apellido"),
                        rs.getInt("edad"), rs.getString("motivo"));
                p.setId(rs.getInt("id"));
                p.setFechaIngreso(rs.getString("fecha_ingreso"));
                // Recupera la urgencia almacenada y la incorpora al objeto Paciente.
                // (Añadido en modulo 2)
                p.setUrgencia(rs.getString("urgencia"));
                lista.add(p);
            }
        }
        return lista;
    }
}
