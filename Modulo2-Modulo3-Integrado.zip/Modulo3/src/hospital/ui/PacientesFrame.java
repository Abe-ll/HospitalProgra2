package hospital.ui;

import hospital.modelo.Persona;
import javax.swing.JComboBox;
import hospital.dao.PacienteDAO;
import hospital.modelo.Paciente;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/** Módulo 3: guarda en MySQL (JDBC) y muestra los registros en una JTable. */
public class PacientesFrame extends JFrame {
    private final JTextField txtNombre = new JTextField(10);
    private final JTextField txtApellido = new JTextField(10);
    private final JTextField txtEdad = new JTextField(4);
    private final JTextField txtMotivo = new JTextField(16);
    // La primera opción permite detectar si falta seleccionar una urgencia.
    // Agrega la etiqueta y el selector de urgencias al formulario.
    
private final JComboBox<String> cmbUrgencia = new JComboBox<>(
        new String[]{"Seleccione urgencia", "Baja", "Media", "Alta", "Crítica"}
);
    
    private final DefaultTableModel modelo = new DefaultTableModel(
           new String[]{"ID", "Nombre", "Apellido", "Edad", "Motivo", "Urgencia", "Ingreso"}, 0) {
        @Override public boolean isCellEditable(int f, int c) { return false; }
    };
    private final PacienteDAO dao = new PacienteDAO();

    public PacientesFrame() {
        super("Módulo 3 - Persistencia JDBC");
        
        // Organiza el formulario en dos columnas: etiqueta y campo.
        // El número de filas se ajusta a los componentes agregados.
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Nombre:"));   form.add(txtNombre);
        form.add(new JLabel("Apellido:")); form.add(txtApellido);
        form.add(new JLabel("Edad:"));     form.add(txtEdad);
        form.add(new JLabel("Motivo:"));   form.add(txtMotivo);
        //Creamos el boton como tal
            form.add(new JLabel("Urgencia:"));
            form.add(cmbUrgencia);
        
            
        JButton btnGuardar = new JButton("Guardar en BD");

            // Deja la primera columna vacía y coloca el botón en la segunda.
            form.add(new JLabel(""));
            form.add(btnGuardar);

        add(form, BorderLayout.NORTH);
        add(new JScrollPane(new JTable(modelo)), BorderLayout.CENTER);

        btnGuardar.addActionListener(e -> guardar());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 450);
        setLocationRelativeTo(null);
        cargarTabla();
    }

    
    
     /**
     * Valida los datos del formulario, construye el paciente
     * y entrega los datos al moduloo de persistencia
     * 
     */
    
    private void guardar() {
        try {
            String nombre = txtNombre.getText().trim();
            String apellido = txtApellido.getText().trim();
            String textoEdad = txtEdad.getText().trim();
            String motivo = txtMotivo.getText().trim();

            // Evita registrar datos obligatorios vacíos.
            // Funciona si uno o mas obligatorios haven falta.
            if (nombre.isEmpty() || apellido.isEmpty()
                    || textoEdad.isEmpty() || motivo.isEmpty()) {
                throw new IllegalArgumentException(
                        "Completa todos los campos.");
            }

            // Definicion de los datos maximos en los campos de nombre, apellido y motivo
            if (nombre.length() > 60 || apellido.length() > 60
                    || motivo.length() > 200) {
                throw new IllegalArgumentException(
                        "Nombre y apellido: máximo 60 caracteres cada uno.\n"
                        + "Motivo: máximo 200 caracteres.");
            }

            // Try catch, si la edad contiene letras o decimales
            int edad = Integer.parseInt(textoEdad);

            // Definicion de los datos maximos en el campo edad
            if (edad < 0 || edad > 120) {
                throw new IllegalArgumentException(
                        "La edad debe estar entre 0 y 120 años.");
            }

            // Que no se pueda sellecionar la opcion original de irgencia
            if (cmbUrgencia.getSelectedIndex() == 0) {
                throw new IllegalArgumentException(
                        "Selecciona un nivel de urgencia.");
            }

            // Construye el objeto y asigna la urgencia seleccionada.
            Paciente paciente = new Paciente(nombre, apellido, edad, motivo);
            paciente.setUrgencia(
                    (String) cmbUrgencia.getSelectedItem());

            // Reutiliza el guardado del módulo 3.
            dao.insertar(paciente);
            
            Persona persona = paciente;

            // Ejecuta obtenerResumen() de Paciente, que amplía el resumen de Persona.
            JOptionPane.showMessageDialog(this,
            "Paciente registrado correctamente.\n" + persona.obtenerResumen(),
            "Registro exitoso",
            JOptionPane.INFORMATION_MESSAGE);
            // La variable está declarada como Persona, pero contiene un Paciente,
            // por eso se ejecuta el método sobrescrito de Paciente (polimorfismo)

            // Limpieza de los datos
            // Solo funciona si el guardado fue exitoso
            
            txtNombre.setText("");
            txtApellido.setText("");
            txtEdad.setText("");
            txtMotivo.setText("");
            cmbUrgencia.setSelectedIndex(0);
            txtNombre.requestFocusInWindow();

            cargarTabla();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "La edad debe ser un número entero, por ejemplo 25.",
                    "Edad inválida", JOptionPane.WARNING_MESSAGE);

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this,
                    ex.getMessage(),
                    "Revisa los datos", JOptionPane.WARNING_MESSAGE);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo guardar el paciente:\n" + ex.getMessage(),
                    "Error de base de datos", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    
     /**
     * Consulta los pacientes registrados mediante PacienteDAO
     * y actualiza los datos que muestra la JTable.
     *
     * Primero elimina las filas del modelo visual para evitar duplicados;
     * esto no afectaregistros de la base de datos. Después recorre los
     * objetos Paciente obtenidos y agrega una fila por cada uno.
     */
    
    
    private void cargarTabla() {
        try {
            modelo.setRowCount(0);
            for (Paciente p : dao.listar()) {
                    // Funcion para añadir una nueva fila
                    // El orden de los valores debe coincidir con los encabezados de la tabla.
                    modelo.addRow(new Object[]{
                        p.getId(), p.getNombre(), p.getApellido(),
                        p.getEdad(), p.getMotivo(), p.getUrgencia(), p.getFechaIngreso()
                    });
            }
            
            
     // Si falla la consulta, informa al usuario sin cerrar la aplicación.
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo leer la base de datos:\n" + ex.getMessage());
        }
    }
}
