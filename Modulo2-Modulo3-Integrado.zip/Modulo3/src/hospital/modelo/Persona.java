
package hospital.modelo;

/** @author Rodrigo Polanco
 * 
 * Representa los datos personales comunes del sistema hospitalario.
 * Sirve como clase base para Paciente.
 * Tambien incluye los getters para los atributos que lo necesitan
 *
 */
public class Persona {
    
    private final String nombre;
    private final String apellido;
    private final int edad;

    /**
     * Inicializa los datos personales.
     *
     * @param nombre nombre de la persona
     * @param apellido apellido de la persona
     * @param edad edad expresada en años
     */
    public Persona(String nombre, String apellido, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    /**
     * Devuelve un resumen de los datos personales.
     * 
     * Las clases hijas pueden sobrescribir este método.
     *
     * @return nombre completo y edad de la persona
     */
    public String obtenerResumen() {
        return nombre + " " + apellido + " | Edad: " + edad;
    }
    
    
    
}
