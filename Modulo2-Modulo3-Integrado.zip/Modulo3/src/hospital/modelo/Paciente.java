package hospital.modelo;

/**
 * Representa los datos de admisión de un paciente. Hereda de Persona el nombre,
 * apellido, edad y sus getters.
 */
public class Paciente extends Persona {

    private int id;
    private String motivo;
    // Se asignará desde el selector de urgencias del formulario.
    // Estado base al no tener seleccionado nada
    private String urgencia = "Sin asignar";

    private String fechaIngreso;

    /**
     * Crea un paciente con sus datos personales y motivo de consulta. Conserva
     * los parámetros que utiliza el módulo de persistencia.
     *
     * @param nombre nombre del paciente
     * @param apellido apellido del paciente
     * @param edad edad expresada en años
     * @param motivo motivo de consulta
     *
     *
     */
    public Paciente(String nombre, String apellido, int edad, String motivo) {

        // Llama al constructor de Persona (clase padre) para inicializar
        // el nombre, apellido y edad que Paciente hereda.
        super(nombre, apellido, edad);
        this.motivo = motivo;
    }

    // Métodos de acceso a los datos propios del paciente. (Setters y Getters)
    // getNombre(), getApellido() y getEdad() se heredan de Persona.
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMotivo() {
        return motivo;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String f) {
        this.fechaIngreso = f;
    }

    /**
     * Devuelve el nivel de urgencia del paciente.
     *
     * @return nivel de urgencia asignado
     *
     */
    public String getUrgencia() {
        return urgencia;
    }

    /**
     * Asigna el nivel de urgencia seleccionado en el formulario.
     *
     * @param urgencia nivel de urgencia del paciente
     *
     */
    public void setUrgencia(String urgencia) {
        this.urgencia = urgencia;
    }

    /**
     *
     * Obtiene el resumen definido en Persona y agrega el motivo. Es la funcion
     * que une el motivo con el resumen de los datos Amplía el resumen de
     * Persona con los datos de admisión.
     *
     * @return datos personales, motivo de consulta y nivel de urgencia
     *
     */
    @Override
    public String obtenerResumen() {
        // Reutiliza los datos personales y agrega motivo y urgencia.
        return super.obtenerResumen()
                + " | Motivo: " + motivo
                + " | Urgencia: " + urgencia;
    }
}
