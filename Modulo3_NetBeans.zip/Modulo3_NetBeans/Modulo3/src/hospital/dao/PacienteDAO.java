package hospital.dao;

import hospital.modelo.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {

    /** INSERT permanente en la base de datos. */
    public void insertar(Paciente p) throws SQLException {
        String sql = "INSERT INTO pacientes (nombre, apellido, edad, motivo) VALUES (?,?,?,?)";
        try (Connection cn = Conexion.obtener(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getApellido());
            ps.setInt(3, p.getEdad());
            ps.setString(4, p.getMotivo());
            ps.executeUpdate();
        }
    }

    /** SELECT de todos los registros para la JTable. */
    public List<Paciente> listar() throws SQLException {
        List<Paciente> lista = new ArrayList<>();
        String sql = "SELECT id, nombre, apellido, edad, motivo, fecha_ingreso FROM pacientes ORDER BY id DESC";
        try (Connection cn = Conexion.obtener();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Paciente p = new Paciente(rs.getString("nombre"), rs.getString("apellido"),
                        rs.getInt("edad"), rs.getString("motivo"));
                p.setId(rs.getInt("id"));
                p.setFechaIngreso(rs.getString("fecha_ingreso"));
                lista.add(p);
            }
        }
        return lista;
    }
}
