package hospital.ui;

import hospital.dao.PacienteDAO;
import hospital.modelo.Paciente;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/** Módulo 3: guarda en MySQL (JDBC) y muestra los registros en una JTable. */
public class PacientesFrame extends JFrame {
    private final JTextField txtNombre = new JTextField(10);
    private final JTextField txtApellido = new JTextField(10);
    private final JTextField txtEdad = new JTextField(4);
    private final JTextField txtMotivo = new JTextField(16);
    private final DefaultTableModel modelo = new DefaultTableModel(
            new String[]{"ID", "Nombre", "Apellido", "Edad", "Motivo", "Ingreso"}, 0) {
        @Override public boolean isCellEditable(int f, int c) { return false; }
    };
    private final PacienteDAO dao = new PacienteDAO();

    public PacientesFrame() {
        super("Módulo 3 - Persistencia JDBC");
        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        form.add(new JLabel("Nombre:"));   form.add(txtNombre);
        form.add(new JLabel("Apellido:")); form.add(txtApellido);
        form.add(new JLabel("Edad:"));     form.add(txtEdad);
        form.add(new JLabel("Motivo:"));   form.add(txtMotivo);
        JButton btnGuardar = new JButton("Guardar en BD");
        form.add(btnGuardar);

        add(form, BorderLayout.NORTH);
        add(new JScrollPane(new JTable(modelo)), BorderLayout.CENTER);

        btnGuardar.addActionListener(e -> guardar());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 450);
        setLocationRelativeTo(null);
        cargarTabla();
    }

    private void guardar() {
        try {
            int edad = Integer.parseInt(txtEdad.getText().trim());
            dao.insertar(new Paciente(txtNombre.getText().trim(), txtApellido.getText().trim(),
                    edad, txtMotivo.getText().trim()));
            txtNombre.setText(""); txtApellido.setText(""); txtEdad.setText(""); txtMotivo.setText("");
            cargarTabla();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "La edad debe ser un número.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error de base de datos:\n" + ex.getMessage());
        }
    }

    private void cargarTabla() {
        try {
            modelo.setRowCount(0);
            for (Paciente p : dao.listar()) {
                modelo.addRow(new Object[]{p.getId(), p.getNombre(), p.getApellido(),
                    p.getEdad(), p.getMotivo(), p.getFechaIngreso()});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo leer la base de datos:\n" + ex.getMessage());
        }
    }
}
