package hospital.modelo;

public class Paciente {
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private String motivo;
    private String fechaIngreso;

    public Paciente(String nombre, String apellido, int edad, String motivo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.motivo = motivo;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public int getEdad() { return edad; }
    public String getMotivo() { return motivo; }
    public String getFechaIngreso() { return fechaIngreso; }
    public void setFechaIngreso(String f) { this.fechaIngreso = f; }
}
